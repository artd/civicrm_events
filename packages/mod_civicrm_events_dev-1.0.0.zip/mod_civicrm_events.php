<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php');

$events = modCiviCRMEventsHelper::getEvents($params);
modCiviCRMEventsHelper::generateLink($events, $params);

$layout = $params->get('layout', 'default');
require(JModuleHelper::getLayoutPath('mod_civicrm_events', $layout));